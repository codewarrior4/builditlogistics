

<?php $__env->startSection('title'); ?> Home page <?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?>
HomeItAll is a market place where you can get the accessories to complete your home and make your home comfortable
<?php $__env->stopSection(); ?>
<?php $__env->startSection('image'); ?>
/assets/images/logo-black.png
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
<script>
	Swal.fire({
		icon: 'success',
		title: 'Done',
		text: '<?php echo e(session("success")); ?>',
		// footer: '<a href="/cart">View Cart</a>'
		})
</script>	

<?php endif; ?>

<?php if(session('error')): ?>
<script>
	Swal.fire({
		icon: 'info',
		title: 'Oops!',
		text: '<?php echo e(session("error")); ?>',
		footer: '<a href="/cart">View Cart</a>'
		})
</script>	
<?php endif; ?>
			<main class="main">
				<div class="container container-not-boxed">
					<div class="info-boxes-slider owl-carousel owl-theme" data-owl-options="{
						'dots': false,
						'loop': false,
						'responsive': {
							'576': {
								'items': 2
							},
							'992': {
								'items': 3
							}
						}
					}">
						<div class="info-box info-box-icon-left">
							<i class="icon-shipping font-35 pt-1"></i>

							<div class="info-box-content pt-1">
								<h4>FREE SHIPPING &amp; RETURN</h4>
								<p class="text-body">Free shipping on all orders over $99</p>
							</div><!-- End .info-box-content -->
						</div><!-- End .info-box -->

						<div class="info-box info-box-icon-left">
							<i class="icon-money pt-1"></i>

							<div class="info-box-content">
								<h4>MONEY BACK GUARANTEE</h4>
								<p class="text-body">100% money back guarantee</p>
							</div><!-- End .info-box-content -->
						</div><!-- End .info-box -->

						<div class="info-box info-box-icon-left">
							<i class="icon-support pt-1"></i>

							<div class="info-box-content">
								<h4>ONLINE SUPPORT 24/7</h4>
								<p class="text-body">Lorem ipsum dolor sit amet.</p>
							</div><!-- End .info-box-content -->
						</div><!-- End .info-box -->
					</div><!-- End .info-boxes-slider -->

					<div class="home-slider outer-container w-auto owl-carousel owl-theme owl-carousel-lazy show-nav-hover nav-large nav-outer mb-2">
						<?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="home-slide home-slide1 banner banner-md-vw" >
							<img class="owl-lazy slide-bg" src="/uploads/<?php echo e($slider->photo); ?>" data-src="/uploads/<?php echo e($slider->photo); ?>" style="max-height:500px !important" alt="slider image">
							<div class="banner-layer banner-layer-middle">
								<h4 class="m-b-3" style="color:white !important"><?php echo e($slider->header); ?></h4>
								<h2 class="font-script mb-0" style="color:white !important"><?php echo e($slider->detail); ?></h2>
								<a href="<?php echo e($slider->url); ?>"  style="color:white !important" class="btn btn-dark btn-lg ls-10"><?php echo e($slider->button); ?></a>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
					</div>

					<div class="home-products-container text-center">
						<div class="row">
							<div class="col-md-4 mb-2">
								<div class="home-products bg-white px-4 pb-2 pt-4">
									<h3 class="section-sub-title mt-1 m-b-1">Featured Products</h3>

									<div class="owl-carousel owl-theme nav-image-center nav-thin px-3 " data-owl-options="{
										'dots': false,
										'nav': true,
										'responsive': {
											'480': {
												'items': 2
											},
											'768': {
												'items': 1
											}
										}
									}">
									<?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="product-default">
											<figure>
												<a href="/products">
													<img src="/uploads/<?php echo e($feature->banner); ?>" alt="product" width="300" height="300">
												</a>
											</figure>
											<div class="product-details">
												<div class="category-list">
													<a href="/category/<?php echo e($feature->category); ?>" class="product-category">category</a>
												</div>
												<h3 class="product-title">
													<a href="product/<?php echo e($feature->pid); ?>"><?php echo e($feature->pname); ?></a>
												</h3>
												
												<div class="price-box">
													<span class="old-price">&#8358; <?php echo e(number_format($feature->compare_price,2)); ?></span>
													<span class="product-price">&#8358; <?php echo e(number_format($feature->price,2)); ?></span>
												</div><!-- End .price-box -->
											</div><!-- End .product-details -->
										</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
								</div>
							</div><!-- End .col-md-4 -->
							<div class="col-md-4 mb-2">
								<div class="home-products bg-white px-4 pb-2 pt-4">
									<h3 class="section-sub-title mt-1 m-b-1">Hot Products</h3>

									<div class="owl-carousel owl-theme nav-image-center nav-thin px-3 " data-owl-options="{
										'dots': false,
										'nav': true,
										'responsive': {
											'480': {
												'items': 2
											},
											'768': {
												'items': 1
											}
										}
									}">
									<?php $__currentLoopData = $hots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="product-default">
											<figure>
												<a href="/products">
													<img src="/uploads/<?php echo e($hot->banner); ?>" alt="product" width="300" height="300">
												</a>
											</figure>
											<div class="product-details">
												<div class="category-list">
													<a href="/category/<?php echo e($hot->category); ?>" class="product-category">category</a>
												</div>
												<h3 class="product-title">
													<a href="product/<?php echo e($hot->pid); ?>"><?php echo e($hot->pname); ?></a>
												</h3>
												
												<div class="price-box">
													<span class="old-price">&#8358; <?php echo e(number_format($hot->compare_price,2)); ?></span>
													<span class="product-price">&#8358; <?php echo e(number_format($hot->price,2)); ?></span>
												</div><!-- End .price-box -->
											</div><!-- End .product-details -->
										</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
								</div>
							</div><!-- End .col-md-4 -->


							<div class="col-md-4 mb-2">
								<div class="home-products bg-white px-4 pb-2 pt-4">
									<h3 class="section-sub-title mt-1 m-b-1">New Arrivals</h3>

									<div class="owl-carousel owl-theme nav-image-center nav-thin px-3" data-owl-options="{
										'dots': false,
										'nav': true,
										'responsive': {
											'480': {
												'items': 2
											},
											'768': {
												'items': 1
											}
										}
									}">
										<?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="product-default">
											<figure>
												<a href="/products">
													<img src="/uploads/<?php echo e($latest->banner); ?>" alt="product" width="300" height="300">
												</a>
											</figure>
											<div class="product-details">
												<div class="category-list">
													<a href="/category/<?php echo e($latest->category); ?>" class="product-category">category</a>
												</div>
												<h3 class="product-title">
													<a href="product/<?php echo e($latest->pid); ?>"><?php echo e($latest->pname); ?></a>
												</h3>
												
												<div class="price-box">
													<span class="old-price">&#8358; <?php echo e(number_format($latest->compare_price,2)); ?></span>
													<span class="product-price">&#8358; <?php echo e(number_format($latest->price,2)); ?></span>
												</div><!-- End .price-box -->
											</div><!-- End .product-details -->
										</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									</div>
								</div>
							</div><!-- End .col-md-4 -->
						</div><!-- End .row -->
					</div><!-- End .row.home-products -->

                    <!-- Promo -->
					
				</div><!-- End .container-not-boxed -->

				<div class="container">
					<div class="products-container bg-white text-center mb-2 pb-5">
						<div class="row product-ajax-grid mb-2">
							<?php $__currentLoopData = $random; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-6 col-sm-4 col-md-3 col-xl-5col">
									<div class="product-default inner-quickview inner-icon">
										<figure>
											<a href="/product/<?php echo e($product->pid); ?>">
											<img style="height:123px !important" src="/uploads/<?php echo e($product->banner); ?>">
												<img style="height:123px !important" src="/uploads/<?php echo e($product->image1); ?>">
											</a>
											<div class="label-group">
												<span class="product-label label-sale"><?php echo e($product->percentage); ?>%</span>
											</div>
											<div class="btn-icon-group">
												
													<a href="/cart/<?php echo e($product->pid); ?>/1/<?php echo e($product->price); ?>" class="btn-icon btn-add-cart" ><i class="icon-shopping-cart"></i></a>
											
											</div>
											<a href="/product/<?php echo e($product->pid); ?>" onclick="window.location('/product/<?php echo e($product->pid); ?>')" class="btn-quickview" title="Quick View">Quick View</a>
										</figure>
										<div class="product-details">
											<div class="category-wrap">
												<div class="category-list">
													<a href="/category/<?php echo e($product->catgeory); ?>" class="product-category">category</a>
												</div>
												<a href="/wishlist/<?php echo e($product->pid); ?>/<?php echo e($product->price); ?>" class="btn-icon-wish"><i class="icon-heart"></i></a>
											</div>
											<h3 class="product-title">
												<a href="/product/<?php echo e($product->pid); ?>"><?php echo e($product->pname); ?></a>
											</h3>
											
											<div class="price-box">
												<span class="old-price">&#8358; <?php echo e(number_format($product->compare_price,2)); ?></span>
												<span class="product-price">&#8358; <?php echo e(number_format($product->price,2)); ?></span>
											</div><!-- End .price-box -->
										</div><!-- End .product-details -->
									</div>
								</div>
							
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<a href="/products" class="btn btn-dark btn-md font1 mb-2">View more</a>
					</div><!-- End .container-box -->
				</div><!-- End .container -->
				
				<div class="container container-not-boxed">
					<div class="banner banner-big-sale mb-5" data-parallax="{'speed': 3.2, 'enableOnMobile': true}" data-image-src="assets/images/banners/banner-4.jpg">
						<div class="banner-content row align-items-center py-3 mx-0">
							<div class="col-md-9 pt-3">
								<h2 class="text-white text-uppercase mb-md-0 px-3">
									<b class="d-inline-block mr-3 mb-1">Big Sale</b>
									New Items 70% off discount
									<small class="text-transform-none align-middle">Online Purchases Only</small>
								</h2>
							</div>
							<div class="col-md-3 py-3 text-center text-md-right">
								<a class="btn btn-light btn-lg mr-3 ls-10" href="#">View Sale</a>
							</div>
						</div>
					</div>

					<div class="feature-boxes-container row mt-6 mb-1">
						<div class="col-md-4">
							<div class="feature-box px-sm-5 px-md-4 mx-sm-5 mx-md-3 feature-box-simple text-center">
								<i class="icon-earphones-alt"></i>

								<div class="feature-box-content">
									<h3 class="mb-0 pb-1">Customer Support</h3>
									<h5 class="m-b-3">Need Assistance?</h5>

									<p>We really care about you and your website as much as you do. Purchasing Porto or any other theme from us you get 100% free support.</p>
								</div><!-- End .feature-box-content -->
							</div><!-- End .feature-box -->
						</div><!-- End .col-md-4 -->

						<div class="col-md-4">
							<div class="feature-box px-sm-5 px-md-4 mx-sm-5 mx-md-3 feature-box-simple text-center">
								<i class="icon-credit-card"></i>

								<div class="feature-box-content">
									<h3 class="mb-0 pb-1">Secured Payment</h3>
									<h5 class="m-b-3">Safe &amp; Fast</h5>

									<p>With Porto you can customize the layout, colors and styles within only a few minutes. Start creating an amazing website right now!</p>
								</div><!-- End .feature-box-content -->
							</div><!-- End .feature-box -->
						</div><!-- End .col-md-4 -->

						<div class="col-md-4">
							<div class="feature-box px-sm-5 px-md-4 mx-sm-5 mx-md-3 feature-box-simple text-center">
								<i class="icon-action-undo"></i>

								<div class="feature-box-content">
									<h3 class="mb-0 pb-1">Returns</h3>
									<h5 class="m-b-3">Easy &amp; Free</h5>

									<p>Porto has very powerful admin features to help customer to build their own shop in minutes without any special skills in web development.</p>
								</div><!-- End .feature-box-content -->
							</div><!-- End .feature-box -->
						</div><!-- End .col-md-4 -->
					</div><!-- End .feature-boxes-container.row -->

					<hr class="mt-0 m-b-5">

					<!-- <div class="brands-slider owl-carousel owl-theme images-center pb-2">
						<img src="assets/images/brands/brand1.png" width="140" height="60" alt="brand">
						<img src="assets/images/brands/brand2.png" width="140" height="60" alt="brand">
						<img src="assets/images/brands/brand3.png" width="140" height="60" alt="brand">
						<img src="assets/images/brands/brand4.png" width="140" height="60" alt="brand">
						<img src="assets/images/brands/brand5.png" width="140" height="60" alt="brand">
						<img src="assets/images/brands/brand6.png" width="140" height="60" alt="brand">
					</div><!-- End .brands-slider -->

					<!-- <hr class="mt-4 mb-0">  -->
				</div><!-- End .container-not-boxed -->
			</main><!-- End .main -->
				
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Build_it_Logistics\resources\views/main/index.blade.php ENDPATH**/ ?>