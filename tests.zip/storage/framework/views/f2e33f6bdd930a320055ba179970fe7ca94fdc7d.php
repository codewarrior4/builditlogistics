<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\Build_it_Logistics\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>