<?php
    use Illuminate\Routing\UrlGenerator;
    $message ='<h4>Welcome to our BuildItCity </h4> <br>
    <p>You requested to change your password</p>
    <p>Please Click on the link below to change your password.</p>';
?>

<?php $__env->startComponent('mail::message'); ?>
 Hello <?php echo e($user->firstname); ?>

    
   <?php echo $message; ?>



<a class="button button-primary" href="<?php echo e(URL::to('/')); ?>/user/password/<?php echo e($user->remember_token); ?>">Change password</a>


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\Build_it_Logistics\resources\views/emails/password.blade.php ENDPATH**/ ?>