<?php
    use Illuminate\Routing\UrlGenerator;
    
?>

<?php $__env->startComponent('mail::message'); ?>
 New Message on Order #<?php echo e($details->orderid); ?>


<?php echo e($details->message); ?>



<a class="button button-primary" href="<?php echo e(URL::to('/')); ?>/user/order/<?php echo e($details->orderid); ?>">Check WebPage</a>


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\Build_it_Logistics\resources\views/emails/order.blade.php ENDPATH**/ ?>