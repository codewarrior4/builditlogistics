
<?php $__env->startSection('title'); ?>
   Order Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="main_content dashboard_part">
    <div class="container-fluid no-gutters">
        <div class="row">
            <div class="col-lg-12 p-0">
                <div class="header_iner d-flex justify-content-between align-items-center">
                    <div class="sidebar_icon d-lg-none">
                        <i class="ti-menu"></i>
                    </div>
                    <?php if(session('msg')): ?>
                        <div class="alert alert-primary alert-dismissible fade show" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            <span class="sr-only">Close</span>
                        </button>
                        <strong><?php echo e(session('msg')); ?>!</strong>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="main_content_iner ">
        <div class="container-fluid plr_30 body_white_bg pt_30">
            <div class="row justify-content-center">
                <div class="col-12">
                    <div class="QA_section">
                        

                        <div class="QA_table ">
                            Items
                            <hr>
                            <!-- table-responsive -->
                            <div class="table-responsive">
                            <table class="table lms_table_active">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Unit</th>
                                        <th scope="col">Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count =>$order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($count +1); ?></th>
                                        <td><?php echo e($order->pname); ?></td>
                                        <td><?php echo e($order->quantity); ?></td>
                                        <td>&#8358; <?php echo e($order->price); ?></td>
                                        <td>&#8358; <?php echo e(number_format($order->price * $order->quantity,2)); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                                    <tr>
                                        <th colspan="5">Total Price &#8358;<?php echo e(number_format($sum,2)); ?></th>
                                    </tr>
                                </tbody>
                            </table>
                            </div>
                        </div>

                        <p class="pt-3 font-weight-bold">Customer Details</p>
                        <hr>
                        <div class="row">

                            <div class="col-sm-12 col-md-6">
                                <div class="white_box mb_30">
                                    <div class="box_header ">
                                        <div class="main-title">
                                            <h3 class="mb-0" >Billing Details</h3>
                                        </div>
                                    </div>
                                    <div class="card shadow shadow-lg">
                                        
                                        <div class="card-body">
                                        <h5 class="card-title"><?php echo e($information->baddress1); ?> <br><?php echo e($information->baddress2); ?></h5>
                                        <p class="card-text"><b class="font-weight-bold">City</b> <?php echo e($information->bcity); ?>.</p>
                                        <p class="card-text"><b class="font-weight-bold">Country</b> <?php echo e($information->bcountry); ?>.</p>
                                        <p class="card-text"><b class="font-weight-bold">Email</b> <?php echo e($information->bemail); ?>.</p>
                                        <p class="card-text"><b class="font-weight-bold">Phone</b> <?php echo e($information->bphone); ?>.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-6">
                                <div class="white_box mb_30">
                                    <div class="box_header ">
                                        <div class="main-title">
                                            <h3 class="mb-0" >Shipping Details</h3>
                                        </div>
                                    </div>
                                    <div class="card shadow shadow-lg">
                                        
                                        <div class="card-body">
                                        <h5 class="card-title"><?php echo e($information->saddress1); ?> <br><?php echo e($information->saddress2); ?></h5>
                                        <p class="card-text"><b class="font-weight-bold">City</b> <?php echo e($information->scity); ?>.</p>
                                        <p class="card-text"><b class="font-weight-bold">Country</b> <?php echo e($information->scountry); ?>.</p>
                                        <p class="card-text"><b class="font-weight-bold">Email</b> <?php echo e($information->semail); ?>.</p>
                                        <p class="card-text"><b class="font-weight-bold">Phone</b> <?php echo e($information->sphone); ?>.</p>
                                        
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-12 col-md-6">
                                <div class="white_box mb_30">
                                    <div class="box_header ">
                                        <div class="main-title">
                                            <h3 class="mb-0" >Customer Details</h3>
                                        </div>
                                    </div>
                                    <div class="card shadow shadow-lg">
                                        
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo e($user->firstname . " " .$user->lastname); ?></h5>
                                            <p class="card-text"><b class="font-weight-bold">Phone</b> <?php echo e($user->phone); ?>.</p>
                                            <p class="card-text"><b class="font-weight-bold">Email</b> <?php echo e($user->email); ?>.</p>
                                        
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="col-sm-12 col-md-6">
                                <div class="white_box mb_30">
                                    <div class="box_header ">
                                        <div class="main-title">
                                            <h3 class="mb-0" >Update Order Status</h3>
                                        </div>
                                    </div>
                                    <div class="card shadow shadow-lg">
                                       
                                        <div class="card-body">
                                            <form action="/admin/order/message" method="post">
                                                <div class="form-group">
                                                    <label for="my-input">Status</label>
                                                   
                                                    <select name="status" class="custom-select mb_30 w-100" >

                                                        <option data-display="Select">Select</option>
                                                        <option <?php echo e(($orders[0]->status =='pending')?'selected':''); ?> value="pending">Pending</option>
                                                        <option <?php echo e(($orders[0]->status =='processing')?'selected':''); ?> value="processing">Processing</option>
                                                        <option <?php echo e(($orders[0]->status =='hold')?'selected':''); ?> value="hold">On Hold</option>
                                                        <option <?php echo e(($orders[0]->status =='cancelled')?'selected':''); ?> value="cancelled">Cancelled</option>
                                                        <option <?php echo e(($orders[0]->status =='review')?'selected':''); ?> value="review" >Under Review</option>
                                                        <option <?php echo e(($orders[0]->status =='ready')?'selected':''); ?> value="ready">Ready For Delivery</option>
                                                    </select>
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="paymentid" value="<?php echo e($orders[0]->paymentid); ?>">
                                                   
                                                </div>
                                                 <input type="submit" value="Update Detail" class="btn btn-outline-primary">
                                            </form>
                                        </div>
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="white_box mb_30">
                                    <div class="box_header ">
                                        <div class="main-title">
                                            <h3 class="mb-0" >Send Customer Message</h3>
                                        </div>
                                    </div>
                                    <div class="card shadow shadow-lg">
                                       
                                        <div class="card-body">
                                            <form action="/admin/order/message" method="post">
                                                <div class="form-group">
                                                  <label for="Subject">Subject</label>
                                                  <input type="text" class="form-control" name="subject" id="Subject" aria-describedby="helpId" placeholder="">
                                                </div>
                                                <div class="form-group">
                                                    <label for="my-textarea">Message</label>
                                                    <textarea id="my-textarea" class="form-control" name="message" rows="3"></textarea>
                                                </div> 
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="paymentid" value="<?php echo e($orders[0]->paymentid); ?>">
                                                    <input type="hidden" name="toemail" value="<?php echo e($user->email); ?>">
                                                    <input type="hidden" name="userid" value="<?php echo e($user->id); ?>">
                                                
                                                 <input type="submit" value="Send Message" class="btn btn-outline-primary">
                                            </form>
                                        </div>
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="white_box mb_30">
                                    <div class="box_header ">
                                        <div class="main-title">
                                            <h3 class="mb-0" > Messages sent</h3>
                                        </div>
                                    </div>
                                    <div class="card shadow shadow-lg">
                                       
                                        <div class="card-body">
                                            <div class="accordion accordion_custom mb_50" id="accordion_ex">
                                                <?php if(count($messages)==0): ?>
                                                    <div class="card shadwo shadow-lg">
                                                        <div class="card-header">
                                                            No messages Yet
                                                        </div>
                                                    </div>
                                                <?php else: ?>
                                                <p class="font-weight-bold pb-4">(Tap on the subject to view message details)</p>
                                                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="card border border-top-0 mb-4 border-primary">
                                                            <div class="card-header" id="headingOne">
                                                                <h2 class="mb-0">
                                                                    <a href="#" class="btn" type="button" data-toggle="collapse"
                                                                        data-target="#collapse<?php echo e($message->id); ?>" aria-expanded="true"
                                                                        aria-controls="collapseOne">
                                                                        <?php echo e($message->subject); ?>

                                                                    </a>
                                                                </h2>
                                                            </div>

                                                            <div id="collapse<?php echo e($message->id); ?>" class="collapse " aria-labelledby="headingOne"
                                                                data-parent="#accordion_ex">
                                                                <div class="card-body">
                                                                    <p><?php echo e($message->message); ?></p>
                                                                    <a href="/admin/ordermessage/delete/<?php echo e($message->id); ?>" class="btn btn-outline-danger">Delete Message</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                <div class="row d-flex align-items-center space-between">
                                                <div class="col-6"> Total Message <?php echo e(count($messages)); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Build_it_Logistics\resources\views/admin/orderdetails.blade.php ENDPATH**/ ?>