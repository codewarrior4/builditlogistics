
<?php $__env->startSection('title'); ?>
    Blog
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="main">
			<nav aria-label="breadcrumb" class="breadcrumb-nav">
				<div class="container">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="/"><i class="icon-home"></i></a></li>
						<li class="breadcrumb-item active" aria-current="page">Blog</li>
					</ol>
				</div>
			</nav>

			<div class="container mb-6">
				<div class="row">
					<div class="col-lg-12">
						
						<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<article class="post">
							<div class="post-media">
								<a href="/blog/<?php echo e($blog->id); ?>">
									<img src="/uploads/<?php echo e($blog->image); ?>" alt="Post">
								</a>
							</div><!-- End .post-media -->

							<div class="post-body">
								<div class="post-date">
									<span class="day"><?php echo e($blog->created_at->format('d')); ?></span>
									<span class="month"><?php echo e($blog->created_at->format('M')); ?></span>
								</div><!-- End .post-date -->

								<h2 class="post-title">
									<a href="/blog/<?php echo e($blog->id); ?>"><?php echo e($blog->title); ?></a>
								</h2>

								<div class="post-content">
									<p><?php echo e(implode(' ', array_slice(explode(' ', strip_tags($blog->description)), 0, 35))); ?></p>

									<a href="/blog/<?php echo e($blog->id); ?>" class="read-more">Read More <i class="icon-angle-double-right"></i></a>
								</div><!-- End .post-content -->

								<div class="post-meta">
									<span><i class="icon-calendar"></i><?php echo e(explode(' ',$blog->created_at)[0]); ?></span>
									<span><i class="icon-user"></i>By <a href="#">Admin</a></span>
									
								</div><!-- End .post-meta -->
							</div><!-- End .post-body -->
						</article>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						

						<?php echo e($blogs->links('pagination::bootstrap-4')); ?>

					</div><!-- End .col-lg-9 -->

					
				</div><!-- End .row -->
			</div><!-- End .container -->
		</main><!-- End .main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Build_it_Logistics\resources\views/main/blog.blade.php ENDPATH**/ ?>