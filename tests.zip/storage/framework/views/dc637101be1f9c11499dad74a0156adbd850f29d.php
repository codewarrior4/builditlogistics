<?php
    use Illuminate\Routing\UrlGenerator;
?>

<?php $__env->startComponent('mail::message'); ?>
 Hello <?php echo e(session('user')->firstname); ?>


    <h4>Welcome to our BuildItCity </h4> <br>
    <p>You can shop get the best available products at our website</p>
    <p>Please Click on the link below to verify your account.</p>


<a  class="button button-primary" href="<?php echo e(URL::to('/')); ?>/user/verify/<?php echo e(session('user')->remember_token); ?>">Verify Email</a>


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\Build_it_Logistics\resources\views/emails/verify.blade.php ENDPATH**/ ?>