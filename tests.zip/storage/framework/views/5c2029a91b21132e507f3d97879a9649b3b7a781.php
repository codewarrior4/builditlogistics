
<?php $__env->startSection('title'); ?>
    Cart
<?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?>
HomeItAll is a market place where you can get the accessories to complete your home and make your home comfortable
<?php $__env->stopSection(); ?>
<?php $__env->startSection('image'); ?>
/assets/images/logo-black.png
<?php $__env->stopSection(); ?>
<?php
	use App\Http\Controllers\Cart;;
	$cart =Cart::cart();
	$count =$cart['count'];
	$sum =$cart['sum'];
	$orderid=date('ymdhis');
	

?>
<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
<script>
	Swal.fire({
		icon: 'success',
		title: 'Done',
		text: '<?php echo e(session("success")); ?>',
		})
</script>	

<?php endif; ?>
<?php if(session('info')): ?>
<script>
	Swal.fire({
		icon: 'info',
		title: 'Removed',
		text: '<?php echo e(session("info")); ?>',
		})
</script>	

<?php endif; ?>
<?php if(session('error')): ?>
<script>
	Swal.fire({
		icon: 'error',
		title: 'Oops',
		text: '<?php echo e(session("error")); ?>',
		})
</script>	

<?php endif; ?>
<main class="main">
			<nav aria-label="breadcrumb" class="breadcrumb-nav">
				<div class="container">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="/index"><i class="icon-home"></i></a></li>
						<li class="breadcrumb-item active" aria-current="page">Shopping Cart</li>
					</ol>
				</div>
			</nav>

			<div class="container mb-6">
				<div class="row">
					<div class="col-lg-8">
						<div class="cart-table-container">
							<table class="table table-responsive table-cart table-inverse">
								<thead>
									<tr>

										<th class="col">Name</th>
										<th class="col">Product</th>
										<th class="col">Price</th>
										<th class="col">Qty</th>
										<th>Subtotal</th>
										<th></th>
									</tr>
								</thead>
								<tbody>
								<?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count => $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($cart->pname); ?></td>

										<td >
											<figure class="product-image-container">
												<a href="/products/<?php echo e($cart->pid); ?>" class="product-image">
													<img src="/uploads/<?php echo e($cart->banner); ?>" alt="product">
												</a>
											</figure>
											
										</td>
											<td>&#8358;<?php echo e($cart->price); ?></td>
											<td>
												<form action="/cart/update" method="post">
												<div class="product-single-qty">
													<input name="quantity" value="<?php echo e($cart->quantity); ?>" class="horizontal-quantity form-control" type="text">
												</div>
												<input value="<?php echo e($cart->pid); ?>" name="pid" type="hidden">
											</td>
												<?php echo csrf_field(); ?>
											<td>&#8358;<?php echo e(number_format($cart->price * $cart->quantity,2)); ?></td>
											<td><div class="float-left">
												<a title="Move to Product Wishlist" href="/wishlist/<?php echo e($cart->pid); ?>/<?php echo e($cart->price); ?>" class="btn-move"><i class="fa fa-heart"></i></a>
												<button type="submit" title="Edit product" style="background: transparent !important; " class="btn btn-move"><span class="sr-only">Edit</span><i class="fa fa-edit"></i></button>
												</form>
												<a href="/cart/delete/<?php echo e($cart->pid); ?>" title="Remove product" class="btn btn-remove"><span class="fa fa-trash"></span></a>
											</div></td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>

								<tfoot>
									<tr>
										<td colspan="4" class="clearfix">
											<div class="float-left">
												<a href="/products" class="btn btn-outline-secondary">Continue Shopping</a>
											</div><!-- End .float-left -->

											<div class="float-right">
												<a href="/cart/clear" class="btn btn-outline-secondary btn-clear-cart">Clear Shopping Cart</a>
											</div><!-- End .float-right -->
										</td>
									</tr>
								</tfoot>
							</table>
						</div><!-- End .cart-table-container -->

						<div class="cart-discount">
							<h4>Apply Discount Code</h4>
							<form action="#">
								<div class="input-group">
									<input type="text" class="form-control form-control-sm" placeholder="Enter discount code"  required>
									<div class="input-group-append">
										<button class="btn btn-sm btn-primary" type="submit">Apply Discount</button>
									</div>
								</div><!-- End .input-group -->
							</form>
						</div><!-- End .cart-discount -->
					</div><!-- End .col-lg-8 -->

					<div class="col-lg-4">
						<div class="order-summary">
							<h3>Summary</h3>

							<h4>
								<a data-toggle="collapse" href="#order-cart-section" class="collapsed" role="button" aria-expanded="false" aria-controls="order-cart-section"><?php echo e(count($carts)); ?> products in Cart</a>
							</h4>

							<div class="collapse" id="order-cart-section">
								<table class="table table-mini-cart">
									<tbody>
										<?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td class="product-col">
													<figure class="product-image-container">
														<a href="/product/<?php echo e($cart->pid); ?>" class="product-image">
															<img src="/uploads/<?php echo e($cart->banner); ?>" alt="product">
														</a>
													</figure>
													<div>
														<h2 class="product-title">
															<a href="/product/<?php echo e($cart->pid); ?>"><?php echo e($cart->pname); ?></a>
														</h2>

														<span class="product-qty">Qty: <?php echo e($cart->quantity); ?></span>
													</div>
												</td>
												<td class="price-col">&#8358; <?php echo e(number_format($cart->price * $cart->quantity,2)); ?></td>
											</tr>
											
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<tr>
												<th>
													Total
												</th>
												<td>
													&#8358; <?php echo e(number_format($sum,2)); ?> 
												</td>
											</tr>
									</tbody>	
								</table>
							</div><!-- End #order-cart-section -->
						</div><!-- End .cart-summary -->
					</div><!-- End .col-lg-4 -->
				</div><!-- End .row -->
			</div><!-- End .container -->	
</main><!-- End .main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Build_it_Logistics\resources\views/main/cart.blade.php ENDPATH**/ ?>