
<?php $__env->startSection('title'); ?>
    Link Expired
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<main class="main">
			<nav aria-label="breadcrumb" class="breadcrumb-nav">
				<div class="container">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="index.html"><i class="icon-home"></i></a></li>
						<li class="breadcrumb-item active" aria-current="page">Error</li>
					</ol>
				</div>
			</nav>

			<div class="container pb-5">
				<div class="heading mb-4">
					<h2 class="title">Invalid Link</h2>
					<h4 class="title">Please check your email again or request for another link</h4>

				</div><!-- End .heading -->
			</div><!-- End .container -->
		</main><!-- End .main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Build_it_Logistics\resources\views/main/expired.blade.php ENDPATH**/ ?>