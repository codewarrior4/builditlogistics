
<?php $__env->startSection('title'); ?>
    Blog Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="main">
			<nav aria-label="breadcrumb" class="breadcrumb-nav">
				<div class="container">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="index.html"><i class="icon-home"></i></a></li>
						<li class="breadcrumb-item active" aria-current="page">Blog</li>
					</ol>
				</div>
			</nav>

			<div class="container mb-6">
				<div class="row">
					<div class="col-lg-12">
						<article class="post single">
							<div class="post-media">
								<div class="post-slider owl-carousel owl-theme">
									<img src="/uploads/<?php echo e($blog->image); ?>" alt="Post">
								</div><!-- End .post-slider -->
							</div><!-- End .post-media -->

							<div class="post-body">
								<div class="post-date">
									<span class="day"><?php echo e($blog->created_at->format('d')); ?></span>
									<span class="month"><?php echo e($blog->created_at->format('M')); ?></span>
								</div><!-- End .post-date -->

								<h2 class="post-title">
								<?php echo e($blog->title); ?>

								</h2>

								<div class="post-meta">
									<span><i class="icon-calendar"></i><?php echo e(explode(' ',$blog->created_at)[0]); ?></span>
									<span><i class="icon-user"></i>By <a href="#">Admin</a></span>
									<span><i class="icon-folder-open"></i>
									</span>
								</div><!-- End .post-meta -->

								<div class="post-content">
									<p><?php echo $blog->description; ?>.</p> 
								</div><!-- End .post-content -->

								<div class="post-share">
									<h3>
										<i class="icon-forward"></i>
										Share this post
									</h3>

									<div class="social-icons">
										<a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url()->full()); ?>" class="social-icon social-facebook" target="_blank" title="Facebook">
											<i class="icon-facebook"></i>
										</a>
										<a href="https://twitter.com/intent/tweet?url=<?php echo e(url()->full()); ?>" class="social-icon social-twitter" target="_blank" title="Twitter">
											<i class="icon-twitter"></i>
										</a>
										<a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo e(url()->full()); ?>" class="social-icon social-linkedin" target="_blank" title="Linkedin">
											<i class="fab fa-linkedin-in"></i>
										</a>
									</div><!-- End .social-icons -->
								</div><!-- End .post-share -->


								<div class="comment-respond">
									<h3>Leave a Reply</h3>
									<!-- only when logged in  -->
									<p>Your email address will not be published. Required fields are marked *</p>

									<?php if(session('user')): ?>
									<form action="/blog/comment" method="post">
										<div class="form-group required-field">
											<label>Comment</label>
											<textarea cols="30" rows="1" name="comment" class="form-control" required></textarea>
										</div><!-- End .form-group -->

                                             <?php echo csrf_field(); ?>
											 <input type="hidden" name="blogid" value=<?php echo e($blog->id); ?>>
											 
										<div class="form-footer">
											<button type="submit" class="btn btn-primary">Post Comment</button>
										</div><!-- End .form-footer -->
									</form>
									<?php else: ?>
									<p>Login To be able to comment *</p>
										
									<?php endif; ?>
								</div><!-- End .comment-respond -->
								<h3>Comments (<?php echo e(count($comments)); ?>)</h3>
								<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<hr>
								<div class="row">
									<div class="media">
										<a class="d-flex" href="#">
											<img  width="100" height="100" class="img-rounded rounded-circle" src="/assets/images/avatar/avatar1.jpg" alt="">
										</a>
										<div class=" ml-5 media-body">
											<h5><?php echo e($comment->comment); ?></h5>
											<span class="font-weight-bold"><?php echo e($comment->firstname  .' '. $comment->lastname); ?></span>
											<br> <br>
											<span ><i class="icon-calendar pr-3"></i><?php echo e(explode(' ',$comment->created_at)[0]); ?></span>
										</div>
									</div>
									
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div><!-- End .post-body -->
						</article><!-- End .post -->

						

					</div><!-- End .col-lg-9 -->

					
				</div><!-- End .row -->
			</div><!-- End .container -->
		</main><!-- End .main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Build_it_Logistics\resources\views/main/blogdetails.blade.php ENDPATH**/ ?>