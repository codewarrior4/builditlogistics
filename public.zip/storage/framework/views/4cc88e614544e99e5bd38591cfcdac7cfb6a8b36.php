<div class="footer_part">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="footer_iner text-center">
                    <p><?php echo e(date('Y ')); ?> © Build It Logistics - Designed by <a noreferrer target="_blank" href="//codewarrior.unaux.com"> Adebayo Mayowa </a></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Build_it_Logistics\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>