
<?php $__env->startSection('title'); ?>
    Password Reset
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<main class="main">
			<nav aria-label="breadcrumb" class="breadcrumb-nav">
				<div class="container">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="index.html"><i class="icon-home"></i></a></li>
						<li class="breadcrumb-item active" aria-current="page">Password Reset</li>
					</ol>
				</div>
			</nav>

			<div class="container pb-5">
				<div class="heading mb-4">
                 
					<h2 class="title">Hello <?php echo e($user->firstname); ?></h2>
					<h4 class="title">Reset your Account Password</h4>

					<p>An email has been sent to your email address <a class="font-weight-bold" target="_blank" href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a>. Check the spam filter if you do not see any mail</p>
				</div><!-- End .heading -->

				<form action="#">
				

					<div class="form-footer">
						<a href="/user/forgot" class="btn btn-primary">Resend Email</a>
					</div><!-- End .form-footer -->
				</form>
			</div><!-- End .container -->
		</main><!-- End .main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Build_it_Logistics\resources\views/user/forget.blade.php ENDPATH**/ ?>