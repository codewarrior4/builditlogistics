<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === 'Laravel'): ?>
<img src="https://laravel.com/img/notification-logo.png" class="logo" alt="Laravel Logo">
<?php else: ?>
<img src="<?php echo e(asset('/assets/images/logo-black.png')); ?>" class="logo" alt="Laravel Logo">
<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH C:\xampp\htdocs\Build_it_Logistics\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>