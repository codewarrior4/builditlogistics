<?php $__env->startComponent('mail::message'); ?>
# Hello <?php echo e(session('Name')); ?>


[slot]: <?php echo e(asset('/assets/images/logo-black.png')); ?> "Logo"
Welcome to our website 
You can shop get the best available products at our website
<!-- <img src="/assets/images/logo-black.png" class="logo" alt="Laravel Logo"> -->
<?php $__env->startComponent('mail::button', ['url' => 'https://builditlogstics.emgss.net/']); ?>
Button Text
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\Build_it_Logistics\resources\views/emails/welcome.blade.php ENDPATH**/ ?>