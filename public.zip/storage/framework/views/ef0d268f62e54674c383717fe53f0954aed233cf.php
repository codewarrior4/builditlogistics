
<?php $__env->startSection('title'); ?>
    FAQ 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="main">
			<div class="container mt-2 pt-0">
				<div class="outer-container page-header page-header-bg text-left" style="background: 70%/cover #D4E1EA url('assets/images/page-header-bg.jpg');">
					<div class="container pl-5">
						<h1><span>FAQ</span>
					</div><!-- End .container -->
				</div><!-- End .page-header -->
			</div><!-- End .container -->

			<nav aria-label="breadcrumb" class="breadcrumb-nav">
				<div class="container">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="/"><i class="icon-home"></i></a></li>
						<li class="breadcrumb-item active" aria-current="page">FAQ</li>
					</ol>
				</div><!-- End .container -->
			</nav>

			<div class="container pt-0 mb-3">
				<div class="about-section">
                        <div class="accordion accordion_custom mb_50" id="accordion_ex">
                            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card">
                                    <div class="card-header bg-primary" id="headingOne">
                                        <h2 class="mb-0">
                                            <a href="#" class="btn text-white" type="button" data-toggle="collapse"
                                                data-target="#collapse<?php echo e($faq->id); ?>" aria-expanded="true"
                                                aria-controls="collapseOne">
                                                <?php echo e($faq->question); ?>

                                            </a>
                                        </h2>
                                    </div>

                                    <div id="collapse<?php echo e($faq->id); ?>" class="collapse" aria-labelledby="headingOne"
                                        data-parent="#accordion_ex">
                                        <div class="card-body">
                                            <span class="badge badge-primary">Answer</span>
                                            <p><?php echo e($faq->answer); ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php echo e($faqs->links('pagination::bootstrap-4')); ?>

                        </div>
				</div><!-- End .about-section -->
			</div><!-- End .container -->

		
		</main><!-- End .main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Build_it_Logistics\resources\views/main/faq.blade.php ENDPATH**/ ?>