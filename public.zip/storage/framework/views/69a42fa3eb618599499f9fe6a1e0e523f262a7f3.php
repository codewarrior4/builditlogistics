
<?php $__env->startSection('title'); ?>
    Checkout
<?php $__env->stopSection(); ?>

<?php
	use App\Http\Controllers\Cart;;
	$cart =Cart::cart();
	$count =$cart['count'];
	$sum =$cart['sum'];
	$orderid=date('ymdhis');
	

?>
<?php $__env->startSection('content'); ?>

<main class="main">
			<nav aria-label="breadcrumb" class="breadcrumb-nav">
				<div class="container">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="index.html"><i class="icon-home"></i></a></li>
						<li class="breadcrumb-item active" aria-current="page">Checkout</li>
					</ol>
				</div>
			</nav>

			<div class="container mb-6">
				<ul class="checkout-progress-bar">
					<li>
						<span>Shipping</span>
					</li>
					<li class="active">
						<span>Review &amp; Payments</span>
					</li>
				</ul>
				<div class="row">
					<div class="col-lg-4">
						<div class="order-summary">
							<h3>Summary</h3>

							<h4>
								<a data-toggle="collapse" href="#order-cart-section" class="collapsed" role="button" aria-expanded="false" aria-controls="order-cart-section"><?php echo e(count($carts)); ?> products in Cart</a>
							</h4>

							<div class="collapse" id="order-cart-section">
								<table class="table table-mini-cart">
									<tbody>
										<?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td class="product-col">
													<figure class="product-image-container">
														<a href="/product/<?php echo e($cart->pid); ?>" class="product-image">
															<img src="/uploads/<?php echo e($cart->banner); ?>" alt="product">
														</a>
													</figure>
													<div>
														<h2 class="product-title">
															<a href="/product/<?php echo e($cart->pid); ?>"><?php echo e($cart->pname); ?></a>
														</h2>

														<span class="product-qty">Qty: <?php echo e($cart->quantity); ?></span>
													</div>
												</td>
												<td class="price-col">&#8358; <?php echo e(number_format($cart->price * $cart->quantity,2)); ?></td>
											</tr>
											
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<tr>
												<th>
													Total
												</th>
												<td>
													&#8358; <?php echo e(number_format($sum,2)); ?> 
												</td>
											</tr>
									</tbody>	
								</table>
							</div><!-- End #order-cart-section -->
						</div><!-- End .order-summary -->

						<div class="checkout-info-box">
							<h3 class="step-title">Ship To:
								<a href="/user/billing" title="Edit" class="step-title-edit"><span class="sr-only">Edit</span><i class="icon-pencil"></i></a>
							</h3>

							<?php if($information == ''): ?>
								<a href="/user/billing" title="Add you Shipping details" class="step-title-edit"><span class="sr-only">Add you Shipping details</span><i class="icon-pencil"></i></a>
							<?php else: ?>
							<address>
								<?php echo e(session('user')->name); ?> <br>
								<?php echo e($information->saddress1); ?> <br>
								<?php echo e($information->saddress2); ?> <br>
								<?php echo e($information->scity); ?> <br>
								<?php echo e($information->scountry); ?> <br>
								<?php echo e($information->semail); ?> <br>
								<?php echo e($information->sphone); ?> <br>
							</address>
							<?php endif; ?>
						</div><!-- End .checkout-info-box -->

					</div><!-- End .col-lg-4 -->

					<div class="col-lg-8 order-lg-first">
						<div class="checkout-payment">
							<h2 class="step-title">Payment Address:</h2>


							<!-- <div class="form-group-custom-control">
								<div class="custom-control custom-checkbox">
									<input type="checkbox" class="custom-control-input" id="change-bill-address" value="1">
									<label class="custom-control-label" for="change-bill-address">My billing and shipping address are the same</label>
								</div>
							</div> -->

							<?php if($information->baddress1 =='' || $information->bcity =='' || $information->bcountry =='' || $information->bphone =='' || $information->bemail =='' ): ?>
								<p>Please Fill up your Billing Details</p>
								<a href="/user/billing" class="btn btn-outline-primary">Fill Billing Details</a>
							<?php else: ?>	
								<div class="container">
									
										<table class="table table-borderless" width="100%">
											<tr>
												<th>Name</th>
												<td><?php echo e(session('user')->firstname ." ".session('user')->lastname); ?></td>
											</tr>
											<tr>
												<th>Address</th>
												<td><?php echo e($information->baddress1); ?> <br>	
													<?php echo e($information->baddress2); ?></td>
											</tr>
											<tr>
												<th>City</th>
												<td><?php echo e($information->bcity); ?> </td>
											</tr>
											<tr>
												<th>Country</th>
												<td><?php echo e($information->bcountry); ?></td>
											</tr>
											<tr>
												<th>Email</th>
												<td><?php echo e($information->bemail); ?> </td>
											</tr>
											<tr>
												<th>Phone</th>
												<td> <?php echo e($information->bphone); ?></td>
											</tr>
										</table>
								</div>
							
							<div class="row">
								<div class="col-6">
									<?php if(session('msg')): ?>
										<div class="alert alert-primary alert-dismissible fade show" role="alert">
											<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
												<span class="sr-only">Close</span>
											</button>
											<strong><?php echo e(session('error')); ?></strong>
										</div>
									<?php endif; ?>
								</div>
								<div class="col-6">
								<form method="POST" action="/pay" accept-charset="UTF-8" class="form-horizontal" role="form">
								<div class="row" style="margin-bottom:40px;">
									<div class="col-md-8 col-md-offset-2">
										
										<input type="hidden" name="email" value="<?php echo e(session('user')->email); ?>">
										<input type="hidden" name="orderID" value="<?php echo e($orderid); ?>">
										<input type="hidden" name="amount" value="100"> 
										<input type="hidden" name="quantity" value="1">
										<input type="hidden" name="currency" value="NGN">
										<input type="hidden" name="metadata" value="<?php echo e(json_encode($array = ['key_name' => 'value',])); ?>" >
										<input type="hidden" name="reference" value="<?php echo e(Paystack::genTranxRef()); ?>">
										<?php echo csrf_field(); ?>
										<!-- <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> -->

										<p>
											<button class="btn btn-primary btn-lg btn-block" type="submit" value="Pay Now!">
												<i class="fa fa-plus-circle fa-lg"></i> Pay  &#8358;<?php echo e(number_format($sum,2)); ?>

											</button>
										</p>
									</div>
								</div>
							</form>
								</div>
							</div>
							<?php endif; ?>
							

							
						</div><!-- End .checkout-payment -->

						<!-- <div class="checkout-discount">
							<h4>
								<a data-toggle="collapse" href="#checkout-discount-section" class="collapsed" role="button" aria-expanded="false" aria-controls="checkout-discount-section">Apply Discount Code</a>
							</h4>

							<div class="collapse" id="checkout-discount-section">
								<form action="#">
										<input type="text" class="form-control form-control-sm" placeholder="Enter discount code"  required>
										<button class="btn btn-sm btn-outline-secondary" type="submit">Apply Discount</button>
								</form>
							</div>End .collapse
						</div>End .checkout-discount -->
					</div><!-- End .col-lg-8 -->
				</div><!-- End .row -->
			</div><!-- End .container -->
</main><!-- End .main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Build_it_Logistics\resources\views/main/checkout.blade.php ENDPATH**/ ?>